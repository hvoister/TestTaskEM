﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestTaskEM.WorkingWithOrders
{
    public class Logs
    {
        public string IpAddress { get; set; }
        public DateTime AccessTime { get; set; }
    }
}
